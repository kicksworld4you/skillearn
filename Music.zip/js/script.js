
const hamburger=document.querySelector('.hamburger');
const nav=document.querySelector('.nav-links');
if(hamburger){hamburger.onclick=()=>nav.classList.toggle('active');}

function validateAffiliateForm(){
if(!document.getElementById('terms').checked){
alert('Please accept terms & conditions');
return false;}
return true;}
